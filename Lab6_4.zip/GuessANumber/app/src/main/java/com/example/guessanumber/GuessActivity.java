package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class GuessActivity extends AppCompatActivity implements View.OnClickListener{
    private Button guessButton;
    private EditText input;
    private int guessNum;
    private TextView hint;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guess);
        hint = findViewById(R.id.hintText);
        guessButton = findViewById(R.id.guessB);
        Random generate = new Random();
        guessNum = generate.nextInt(100)+1;
        guessButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        input = findViewById(R.id.inputNum);
        Intent i = new Intent(this,ResultActivity.class);
        String inputString = input.getText().toString();
        int inputNum = Integer.parseInt(inputString);
        if(inputNum<guessNum) hint.setText("Your guess is too low.");
        else if(inputNum>guessNum) hint.setText("Your guess is too high.");
        else if(inputNum == guessNum) startActivity(i);
    }
}
