package lab5_1;
        
public class Zellers {
    
    private int dayOfMonth;
    private int month;
    private int year;
    private int h, q, m,j,k;
    
    public Zellers(int dayOfMonth,int month,int year){
        this.dayOfMonth = dayOfMonth;
        this.month = month;
        this.year = year;    
    }
    enum Day{
        SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"),
        FRIDAY("Friday"), SATURDAY("Saturday");
        private  final  String dayOut;
        Day(String dayOut){
            this.dayOut = dayOut;
        }
        public String getDay(){
            return dayOut;
        }
    }
    public Day getDayOfWeek(){
        q = dayOfMonth;
        m = month;
        if (m==1){year-=1;m=13;}
        if (m==2){year-=1;m=14;}
        j = year/100;
        k = year%100;
        Day getDay = Day.SUNDAY;
        h = (q+(26*(m+1)/10)+k+(k/4)+(j/4)+(5*j))%7;
                
        switch(h)
        {
            case 0: getDay = Day.SATURDAY; break;
            case 1: getDay = Day.SUNDAY; break;
            case 2: getDay = Day.MONDAY; break;
            case 3: getDay = Day.TUESDAY; break;
            case 4: getDay = Day.WEDNESDAY; break;
            case 5: getDay = Day.THURSDAY; break;
            case 6: getDay = Day.FRIDAY; break;
        }
        return getDay;
    }
    
}
