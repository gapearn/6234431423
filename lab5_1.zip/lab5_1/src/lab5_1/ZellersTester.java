package lab5_1;

import java.util.Scanner;

public class ZellersTester {
    
    public static void main(String[] args) { 
        Scanner get = new Scanner(System.in);
        System.out.print("Enter year (e.g., 2012): ");
        int year = get.nextInt();
        System.out.print("Enter month  (1-12): ");
        int month = get.nextInt();
        System.out.print("Enter day of the month (1-31): ");
        int day = get.nextInt();
        Zellers print = new Zellers(day,month,year);
        System.out.println("Day of the week is " + print.getDayOfWeek().getDay());
    }
}

    
