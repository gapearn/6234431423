package lab10_1;

public class Secretary extends Employee implements Evaluation {
    private int typingSpeed;
    private int score[];
   
    public Secretary(String name, int salary,int score[],int typingSpeed){
        super(name,salary);
        this.typingSpeed = typingSpeed;
        this.score = score;
    }
        
    @Override
    public char grade(double totalPoint){
        if (totalPoint>=90){
            super.setSalary(18000);
            return 'P';
        } else {
            return 'F';
        }
        
    }

    @Override
    public double evaluate() {
        int whole = 0;
        for (int i=0 ; i < score.length ; i++) {
            whole += score[i];  
        } 
        return whole;
    }
}
