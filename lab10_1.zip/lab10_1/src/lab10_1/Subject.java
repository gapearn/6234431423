package lab10_1;

public class Subject implements Evaluation {
    private String subjName;
    private int score[];
    
    public Subject(String subjName,int score[]){
        this.subjName = subjName;
        this.score = score;
    }

    @Override
    public double evaluate() {
        int whole = 0;
        for (int i=0 ; i < score.length ; i++) {
            whole += score[i];  
        } 
        return whole/score.length;
    }

    @Override
    public char grade(double totalPoint) {
        if (totalPoint>=70){
            return 'P';
        } else {
            return 'F';
        }
    }
    
    @Override
    public String toString(){
        return subjName;
    }
    
    
    
}
