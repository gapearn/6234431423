package lab10_2;

import java.util.ArrayList;

public class BusTester {

    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<Bus>();
        arr.add(new Hybrid(45,1200000,600,150,1));
        arr.add(new CNGBus(50,1000000,200,2));
        for (Bus i : arr){
            System.out.println("ID: "+i.getID());
            if(i instanceof Hybrid){
                Hybrid hb = (Hybrid) i;
                System.out.println("Emission Tier: "+hb.getEmissionTier()+"\nAccel: "+hb.getAccel());
            } else if(i instanceof CNGBus){
                CNGBus cb = (CNGBus) i;
                System.out.println("Emission Tier: "+cb.getEmissionTier()+"\nAccel: "+cb.getAccel());
            }
        }
    }
    
}
