package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class WordCheck {

    public static void main(String[] args) {
        File f = new File("wordlist.txt");
        ArrayList<String> wordList = new ArrayList<>();
        try{
            Scanner readFile = new Scanner(f);
            while (readFile.hasNextLine()) {
                String line = readFile.nextLine();
                wordList.add(line);
            }
        }catch (FileNotFoundException e){
            System.out.println(e);
        }
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String text = sc.nextLine();
        String[] word = text.split(" ");
        boolean containAll = true;
        System.out.println("Words not contained:");
        for(int i=0;i<=word.length-1;i++)
            if(!wordList.contains(word[i])){
                System.out.println(word[i]);
                containAll=false;
            }
        if(containAll)
            System.out.println("N/A");
    }
}
