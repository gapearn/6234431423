package com.example.eastersunday;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    private Button backButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        String text1 = intent.getStringExtra(MainActivity.monthresult);
        int text2 = intent.getIntExtra(MainActivity.dayresult,0);

        TextView textView1 = (TextView) findViewById(R.id.resultMonth);
        TextView textView2 = (TextView) findViewById(R.id.resulthDay);

        textView1.setText(text1);
        textView2.setText(" "+text2);

        //resultText.setText(month + day);
      backButton = (Button) findViewById(R.id.back);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //openMainActivity();
                onBackPressed();
            }
            /*public  void  openMainActivity(){
                Intent intent1 = new Intent(SecondActivity.this,MainActivity.class);
                startActivity(intent1);
            }*/
        });
    /* not use
       if (getIntent().hasExtra("com.example.eastersunday.monthresult")) {
            TextView tv = (TextView) findViewById(R.id.resultText);
            String text1 = getIntent().getExtras().getString("com.example.eastersunday.monthresult");
            tv.setText(text1);
        }

        if (getIntent().hasExtra("com.example.eastersunday.dayresult")) {
            TextView tv = (TextView) findViewById(R.id.resultText);
           int text2 = Integer.parseInt(tv.getText().toString());
            // int text2 = getIntent().getExtras().getString("com.example.eastersunday.dayresult");
            tv.setText(text2);


        TextView tv = (TextView) findViewById(R.id.resultText);

        tv.setText(MainActivity);*/
    }

}
