package com.example.eastersunday;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public  static  final String monthresult = "com.example.eastersunday.monthresult";
    public  static  final String dayresult = "com.example.eastersunday.dayresult";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button sendBotton = (Button) findViewById(R.id.sendBotton);
        sendBotton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText enterYearEditText = (EditText) findViewById(R.id.enterYearEditText);
                TextView resultText = (TextView) findViewById(R.id.resultMonth);

                int y = Integer.parseInt(enterYearEditText.getText().toString());
                int a = y%19;
                int b = y/100;
                int c = y%100;
                int d = b/4;
                int e = b%4;
                int g = (8*b+13)/25;
                int h = (19*a+b-d-g+15)%30;
                int j = c/4;
                int k = c%4;
                int m = (a+11*h)/319;
                int r =(2*e+2*j-k-h+m+32)%7;
                int n = (h-m+r+90)/25;
                int day =(h-m+r+n+19)%32;

                
                String month = "";
                switch (n){
                    case 1: month = "January";break;
                    case 2: month = "February";break;
                    case 3: month = "March";break;
                    case 4: month = "April";break;
                    case 5 : month = "May";break;
                    case 6 : month = "June";break;
                    case 7 : month = "July";break;
                    case 8 : month = "August";break;
                    case 9 : month = "September";break;
                    case 10 : month = "October";break;
                    case 11 : month = "November";break;
                    case 12 : month = "Decemver";break;
                    default: month = "Invalid month";break;

                }

                Intent startIntent = new Intent(getApplicationContext(),SecondActivity.class);
                startIntent.putExtra(monthresult,month);
                startIntent.putExtra(dayresult,day);
                startActivity(startIntent);

                resultText.setText(month + day);
                //startActivity(new Intent(MainActivity.this, SecondActivity.class));

            }
        });

    }
}