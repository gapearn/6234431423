
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class Purse {
    private ArrayList<String> coinName;
    
    public Purse() {
        coinName = new ArrayList<String>();
    }
    
    public void addCoin(String coinName) {
        this.coinName.add(coinName);
    }
    
    public String toString() {
        return String.valueOf(coinName);
    }
    
    public ArrayList<String> reverse() {
        ArrayList<String> temp = new ArrayList<String>();
        for (int i = coinName.size() - 1; i > -1; i--) {
            temp.add(coinName.get(i));
        }
        return temp;
    }
    
    public void transfer(Purse other) {
        for (int i = coinName.size(); i > 0; i--) {
            other.coinName.add(coinName.get(0));
            coinName.remove(0);
        }
    }
    
    public boolean sameContents(Purse other) {
        if (coinName.size() == other.coinName.size()) {
            for (int i = 0; i < coinName.size(); i++) {
                if (!(coinName.get(i).equals(other.coinName.get(i)))) {
                    return false;
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    
    public boolean sameCoins(Purse other) {
        ArrayList<String> temp = new ArrayList<String>();
        for (String name : other.coinName) {
            temp.add(name);
        }
        if (coinName.size() == temp.size()) {
            for (int i = 0; i < coinName.size(); i++) {
                for (int j = 0; j < temp.size(); j++) {
                    if (coinName.get(i).equals(temp.get(j))) {
                        temp.remove(temp.get(j));
                    }
                }
            }
            if (temp.isEmpty()) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
}
