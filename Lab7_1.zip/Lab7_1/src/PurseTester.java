/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class PurseTester {
    public static void main(String args[]) {
        Purse purse1 = new Purse();
        Purse purse2 = new Purse();
        purse1.addCoin("Dime");
        purse1.addCoin("Nickel");
        purse1.addCoin("Quarter");
        purse2.addCoin("Quarter");
        purse2.addCoin("Dime");
        
        System.out.println(purse1.toString());
        System.out.println(purse1.reverse().toString());
        System.out.println(purse2.toString());
        purse1.transfer(purse2);
        System.out.println(purse1.toString());
        System.out.println(purse2.toString());
        
        Purse purse3 = new Purse();
        Purse purse4 = new Purse();
        purse3.addCoin("Dime");
        purse3.addCoin("Nickel");
        purse3.addCoin("Dime");
        purse3.addCoin("Quarter");
        purse4.addCoin("Dime");
        purse4.addCoin("Quarter");
        purse4.addCoin("Nickel");
        purse4.addCoin("Dime");
        System.out.println(purse3.sameContents(purse4));
        System.out.println(purse3.sameCoins(purse4));
        
    }
}
