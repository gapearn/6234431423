package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue{
    ArrayList que = new ArrayList<>();
    
    @Override
    public void enqueue(Object o){
        que.add(o);
        System.out.println(o+" is added in queue");
    }
    
    @Override
    public void dequeue(){
        System.out.println("Now playing "+que.get(0));
        que.remove(0);   
    }
    
}



//จงสร้างคลาส MusicBox สืบทอดจาก SimpleQueue 
//        เพื่อจําลองเป็นตู้เพลง มีอาร์เรย์ลิสต์เก็บข้อมูลเพลงตามคิว
//ท่ีใส่เข้ามาโดยให้overridemethod enqueue() เพื่อรับชื่อเพลงเอามาใส่ในคิวเพลง(อาร์เรย์ลิสต์)ที่ต้องเล่น 
//        แล้วแสดงผลลัพธ์ว่า ชื่อเพลง is added in queue 
//และ override method dequeue() เพื่อเอาเพลงออก จากคิว (อาร์เรย์ลิสต์) ไปเล่น 
//        และแสดงผลลัพธ์ว่า Now playing ชื่อเพลง