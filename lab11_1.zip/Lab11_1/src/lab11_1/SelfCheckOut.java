package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue {
    ArrayList<Product> list = new ArrayList<>();
    public double purchase;
    
    @Override
    public void enqueue(Object o){
        Product p = (Product) o;
        list.add(p);        
        System.out.println(p.getName()+" is added in queue");
    }
    
    @Override
    public void dequeue(){
        purchase = purchase + list.get(0).getPrice();
        list.remove(0);
    }
    
    public double getAmount(){
        return purchase;
    }
    
}





//จงสร้างคลาส SelfCheckOut สืบทอดจาก SimpleQueue 
//เพื่อจําลองเป็นเครื่องชําระเงินค่าสินค้าด้วยตนเอง 
//(จินตนาการเป็นแบบที่เราวางสินค้าไปบนสายพานแล้วสายพานค่อย ๆ ลําเลียงไปผ่านตัวอ่านเพื่อคํานวณเงินที่ ต้องชําระ) 
//โดย override method enqueue() 
//  เพื่อรับสินค้ามาใส่ในคิวสินค้า (อาร์เรย์ลิสต์) ที่ต้องชําระเงิน 
//    แล้วแสดงผลลัพธ์ว่า ชื่อสินค้า is added in queue และ
//override method dequeue() 
//  เพื่อเอาสินค้าออกจาก คิว (อาร์เรย์ลิสต์) 
//    ไปคิดเงินรวมที่ต้องชําระ
