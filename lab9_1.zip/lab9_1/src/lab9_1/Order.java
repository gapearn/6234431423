package lab9_1;

import java.util.ArrayList;

public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private  ArrayList<Pizza> p = new ArrayList<Pizza>() ;
    
    public void addPizza(Pizza p){
        this.p.add(p);
    }
    
    public String getOrderDetail(){
        this.id = cntOrder;
        String input;
        String index = String.valueOf(id);
        input = "Order id : "+ index +"\n"; 
        input += c.getName() + " tel : " + c.getTel() + c.getD() + "\n"; 
        for(int i = 0; i<p.size();i++){
            input += p.get(i).getName() + " price : " + String.valueOf(p.get(i).getPrice()) + p.get(i).getSpecial() + "\n"; 
        }
        input += "Total pieces : " + String.valueOf(p.size()) + "\n"; 
        input += "Total cost : "; 
        double price = 0;
        for(int i = 0;i<p.size();i++ ){
            price += p.get(i).getPrice() - p.get(i).getPrice()*(c.getDiscount()/100);
        }
        input += String.valueOf(price);
        return input;
    }
    
    public double calculatePayment(){
        double price = 0;
        for(int i = 0;i<p.size();i++ ){
            price += (p.get(i).getPrice()) - (p.get(i).getPrice())*(c.getDiscount()/100);
        }
        return price;
    }
    
    public Order(Customer c){
        this.c = c;
        cntOrder += 1;
    }
    
    public String toString(){
        String person = "";
        for (Object a : p){
            person += a;
        }
        return person;
    }
}


