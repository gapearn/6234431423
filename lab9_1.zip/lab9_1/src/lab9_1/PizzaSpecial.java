package lab9_1;

public class PizzaSpecial extends Pizza {
    private final String special;
    
    public PizzaSpecial(String name,double price,String special){
        super(name,price);
        this.special = special;
    }
    
    @Override
    public String getSpecial(){
        return "  special : "+ special;
    } 
}
