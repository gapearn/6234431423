package lab9_2;

public class sine extends Taylor {
    public sine(int k,double x){
        super.setlter(k);
        super.setValue(x);
    }
    
    public double getApprox(){
        int k = super.getlter();
        double x=super.getValue();
        double answer = 0;
        for(int n=0;n<=k;n++){
            answer += Math.pow(-1,n)*Math.pow(x,(2*n)+1)/super.factorial((2*n)+1);
        }
        return answer;
    }
    
    public void printValue() {
        System.out.println("Value from Math.sine()is " + Math.sin(super.getValue()) + ".");
        System.out.println("Approximated value    is " + this.getApprox() + ".");
    }
    
}
