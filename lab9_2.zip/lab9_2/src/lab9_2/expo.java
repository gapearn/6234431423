package lab9_2;

public class expo extends Taylor {
    public expo(int k,double x){
        super.setlter(k);
        super.setValue(x);
    }
    
    public double getApprox(){
        int k = super.getlter();
        double x = super.getValue();
        double answer = 1;
        for(int n=1;n<=k;n++){
            answer += Math.pow(x,n)/super.factorial(n);
        }
        return answer;
    }
    
    public void printValue() {
        System.out.println("Value from Math.exp() is " + Math.exp(super.getValue()) + ".");
        System.out.println("Approximated value    is " + this.getApprox()+".");
    } 
    
}
