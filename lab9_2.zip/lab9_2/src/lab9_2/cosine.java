package lab9_2;

public class cosine extends Taylor {
    public cosine(int k, double x){
        super.setlter(k);
        super.setValue(x);
    }
    
    public double getApprox(){
        int k = super.getlter();
        double x = super.getValue();
        double answer = 1;
        for(int n=1;n<=k;n++){
            answer += Math.pow(-1,n)*Math.pow(x,(2*n))/super.factorial((2*n));
        }
        return answer;
    }
    
    public void printValue() {
        System.out.println("Value from Math.cos() is "+Math.cos(super.getValue())+".");
        System.out.println("Approximated value    is "+this.getApprox()+".");
    }
              
}
