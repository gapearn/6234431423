package lab9_2;

import java.util.Scanner;

public abstract class Taylor {
    private int k;
    private double x;
    
    public int factorial(int n){
        int result = 1 ;
        
        for (int i = n;i >= 1;i--) {
            result *= i;
        }
        return result;
    }
    
    public void setlter(int k){
        this.k = k;
    }
    
    public int getlter(){
        return k;
    }
    
    public void setValue(double x){
        this.x = x;
    }
    
    public double getValue(){
        return x;
    }
    
    public abstract void printValue();
    
    public abstract double getApprox();
    
}
